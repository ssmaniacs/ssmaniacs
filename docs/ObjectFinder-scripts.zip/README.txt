# Generating Object Finder from SS game data

## Extract resource files from SS game directory

1. Find *.pak files from SS install directory
    MacOS: /Applications/SecretSociety.app/Contents/Resources/
    Windows: C:\Program Files\WindowsApps\828B5831.TheSecretSociety-HiddenMystery_1.25.2500.0_x86__ytsefhwckbdv6\
    Android: ?
    iOS: ?


  On MacOS, there are more than 50 *.pak files in all (several system files
  and one file for every scene).
  $ find /Applications/SecretSociety.app/Contents/Resources/ -name '*.pak'

  On Windows there are only a few (one of them containing data for all scenes).
  C:\> dir /s /b C:\Program Files\WindowsApps\828B5831.TheSecretSociety-HiddenMystery_1.25.2500.0_x86__ytsefhwckbdv6\*.pak

  I have no idea about Android and iOS.


2. Extract all *.pak files into a same directory of your choice.
  *.pak files are actually ordinary tar files so you can extract with regular
  tar command (on Linux or MacOS or any other unix like systems)

  $ tar -xf xxx.pak -C {some-directory}

  The result is a directory tree like this:

  {some-directory}/
    1024/
      cursors/
      images/
        levels/
          ho_chapter1/  *
      levels/           *
      loading/
      particles/
      properties/       *
      puzzles/
      scripts/
    1228/
    1280/
    1366/
    2048/
    2456/
    2732/

  Directories marked with '*' above are used in the following procedures.


## Generate Object Finder data from game data files

These scripts are written specifically for Secret Society game files and
wouldn't work with other games.

1. Read SS resource files and generate intermediate data.

  SCRIPT USAGE:
    $ python ReadSceneResource.py {resdir}

  ARGUMENT:
    resdir  root directory of extracted SS files ({some directory} mentioned above).

  INPUT:
    {resdir}/1024/properties/data_scenes.xml
      Internal name for each scene, picture file path, etc.

    {resdir}/1024/levels/scene_{id}.xml
      Picture internal name, picture file name, coodinates, size, etc.

    {resdir}/1024/images/levels/ho_chapter1/{scene name}/.../*.xml
      Animation definition (described in scene_{id}.xml files)

  OUTPUT:
    ./scene_{id}_data.json (for each scene)

    Intermediate data file containing the following information:

    {
      "id": <int>,      Internal scene ID.
      "name": <str>,    Internal scene name.
      "xml": <str>,     Relative path of scene_?.xml file.
      "levels": [...],  Level up information. Irrelevant to Object Finder.
      "images": {
        "background": { Background image information
          "{layer}": [  Picture layer (z-order)
            {
              "type": "pic" or "ani",  Still image or animation frame
              "name": <str>,           Internal picture name
              "orig": <str>,           Original picture file path
              "conv": <str>,           Converted picture file path
              "x": <int>,              X coordinate
              "y": <int>               Y coordinate

              Following fields are only present for animation frames
              "ani": 1,                Animation frame indicator
              "regx": <int>,           Relative X coordinate
              "regy": <int>,           Relative Y coordinate
              "cropx": <int>,          Frame X coordinate
              "cropy": <int>,          Frame Y coordinate
              "cropw": <int>,          Frame width
              "croph": <int>,          Frame height
              "frame": <int>           Frame number
            }
          ]
        },
        "objects": {    Hidden object information
          "form": [     Text/silhouette modes
            {
              "name": <str>,   Internal object name
              "orig": <str>,   Original silhouette picture file path
              "conv": <str>,   Converted silhouette picture file path
              "images": [      Hidden pictures (6 pictures for each object)
                {
                  "pic": {          Picture of the object
                    "name": <str>,  Internal picture name
                    "orig": <str>,  Original picture file path
                    "conv": <str>,  Converted picture file path
                    "layer": <int>, Picture layer (z-order)
                    "x": <int>,     Object X coordinate
                    "y": <int>,     Object Y coordinate
                    "w": <int>,     Object width
                    "h": <int>,     Object height
                  },
                  "cover": {        Only present for partly hidden objects
                    "name": <str>,  Internal picture name
                    "orig": <str>,  Original picture file path
                    "conv": <str>,  Converted picture file path
                    "layer": <int>, Picture layer (z-order)
                    "x": <int>,     Picture X coordinate
                    "y": <int>,     Picture Y coordinate
                    "w": <int>,     Picture width
                    "h": <int>,     Picture height
                  }
                }
              ],
            },
          ],
          "part": [                 Pieces mode picture information
            "name": <str>,          Internal object name (whole)
            "orig": <str>,          Original picture path
            "conv": <str>,          Converted picture path
            "pieces": [             Constructing piece (5 pieces for each object)
              "name": <str>,        Internal name (menu picture)
              "orig": <str>,        Original picture path
              "conv": <str>,        Converted picture path
              "images": [           Hidden pictures (5 pictures for each piece)
                {
                  "pic": {...},     Hidden object (same as "form" data)
                  "cover": {...}    cover picture (same as "form" data)
                }
              ]
            ]
          ],
          "morph": [                Morph mode picture information
            {
              "name": <str>,        Internal object name
              "images": [           Hidden picture info (5 pictures for each object)
                {
                  "pic1": {...},    1st morph (same as "form" data)
                  "pic2": {...},    2nd morph (same as "form" data)
                  "cover": {...}    cover picture (same as "form" data)
                }
              ]
            }
          ]
        }
      }
    }


2. Extract multilingual data for Object Finder.

  SCRIPT USAGE:
    $ python MakeLangJson.py {resdir} {datadir} {outdir}

  ARGUMENTS:
    resdir    root directory of extracted SS files ({some directory} mentioned above).
    datadir   directory where scene_?_data.json files are stored (usually ".").
    outdir    directory to store generated multilingual data file (usually ".")

  INPUT:
    {datadir}/scene_{id}_data.json
      Previously generated with ReadSceneResource.py

    {datadir}/1024/properties/default*.xml
      Multilingual data (scene name, object name, etc)

  OUTPUT:
    {outdir}/scene_info.{lang}.json
    This script generates json files for all 12 languages SS currently supports.

    {
       "items": {...},    Some special item name. Irrelevant to Object Finder.
       "levels": {...},   Scene level name.  Irrelevant to Object Finder.
       "modes": {         Mode name.  "Text", "Night", "Pairs", etc.
         {internal name}: <str>,
       },
       "objects": {       Hidden object name for Text/Night modes.
         {internal name}: <str>,
       },
       "scenes": {        Scene name.
         {scene id}: <str>,
       }
    }


3. Convert scene and object pictures

  Uses ImageMagick (https://www.imagemagick.org/script/index.php)

  SCRIPT USAGE:
    $ python MakeConvertList.py {resdir} {imgdir} scene_*_data.json > convlist.txt
    $ bash convert_images.sh convlist.txt

    Optionally you can generate low-res pictures from converted pictures:
    $ bash shrink_images.sh {imgdir} {low-res-imgdir}

  ARGUMENTS:
    resdir  root directory of extracted SS files ({some directory} mentioned above).
    imgdir  directory to store converted picture files
    scene_*_data.json  All intermediate scene info files generated previously.

  INPUT:
    scene_*_data.json
      Scene background and hidden object picture data.

    {resdir}/1024/images/levels/ho_chapter1/{scene name}/.../*
      Scene background and hidden object pictures (jpg, png, etc.)

  OUTPUT:
    {imgdir}/{scene_name}.{mode}/*.png
      Converted pictures to be rendered on Object Finder.


4. Generate scene picure info files for Object Finder

  SCRIPT USAGE:
    $ python MakeSceneJson.py {imgdir} {outdir} bg obj embed scene_*_data.json

  ARGUMENTS:
    imgdir  directory path where converted picture files are stored
    outdir  directory to store generated picture info files
    bg      specifies to generate background picture info files
    obj     specifies to generate object picture info files
    embed   specifies to embed picture data into picture info files
    scene_*_data.json  All ntermediate scene info files generated previously.

  INPUT:
    {imgdir}/{scene_name}.{mode}/*.png
      Converted picture files

    scene_*_data.json
      Scene background and hidden object picture data.

    scene_template.json
      Hand tweaked background picture data.
      It states whether each background element is an effect element or not
      (rays, smokes, haloes, etc), and if it should be drawn or skipped.

  OUTPUT:
    {outdir}/scene_{id}_bg.json
      Backgournd picture data for Object Finder

      [     Background picture info (number of items varies from scene to scene)
        {
          "data": "data:image/...",     Base64 encoded picture data
          "layer": <int>,               Picture Z-order (not currently used)
          "path": <str>,                picture path (not used if "data" is present)
          "x": <int>,                   picture X coordinate
          "y": <int>                    picture Y coordinate
        }
      ]

    {outdir}/scene_{id}_obj.json
      Object picture data for Object Finder

      {
        "form": [     Text/Night/Silhouette mode objects
          {
            "data": "data:image/...",     Silhouette picture data
            "name": <str>,                Internal object name
            "path": <str>,                Silhouette picture path (not used if "data" is present)
            "images": [                   Hidden object pictures (6 pictures per object)
              {
                "pic": {                      Object picture
                  "data": "data:image/...",   Picture data
                  "layer": 3,                 Picture Z-Order (not currently used)
                  "path": <str>,              Picture path (not used if "data" is present)
                  "x": 389,                   Picture X coordinate
                  "y": 496,                   Picture Y coordinate
                  "w": 38,                    Picture width
                  "h": 30,                    Picture height
                },
                "cover": {                    Cover picture if the object is partly hidden
                  ...                         Same as "pic" data
                }
              }, 
            ]
          }
        ],
        "morph": [    Morph mode objects
          {
             "images": [                    Morph picture sets (5 sets per object)
               {
                 "pic1": {...},             Morph1 picture info (same as "form" data)
                 "pic2": {...},             Morph2 picture info (same as "form" data)
                 "cover": {...},            Cover picture info (same as "form" data)
               }
             ]
          }
        ],
        "part": [     Pieces mode objects
          {
            "data": "data:image/...",   Combined object image data
            "path": <str>,              Combined object image path (not used if "data" is present)
            "pieces": [                 Object pieces (5 pieces per object)
              {
                "data": "data:image/...", Piece picture data for menu
                "path": <str>,            Piece picture path (not used if "data" is present)
                "images": [               Hidden pictures (5 pictures per piece)
                  {
                    "pic": {...},         Hidden picture info (same as "form" data)
                    "cover": {...}        Cover picture info (same as "form" data)
                  }
                ]
              }
            ]
          }
        ]
      }


## Executing Object Finder

Place generated scene_*_bg.json, scene_*_obj.json and scene_info.*.json
files into the same directory as ObjectFinder.html and open ObjectFinder.html
with your preferred browser.

Note that some modern browsers (most notably Chrome) does not allow locally
opended pages (i.e. pages opened with file:// scheme) to dynamically load
other resource files. If you want to use one of such browsers, you must
access ObjectFinder.html through some kind of http server.

The simplest method would be to use python SimpleHTTPServer module, since
you have to be able to run python if you've been able to generate necessary
json files.
Simply execute:
    $ cd {directory where ObjectFinder.html is stored}
    $ python -m SimpleHTTPServer 8888 (or any unused port number)

Then access the locally running server with the following URL:
    http://localhost:8888/

